Title:Dungeon - now with diagonal walls 
Shain Allen
9/9/2019
effort: not really as its not done yet
the new feature might give me the most
trubble when I get around to it but for now its been
the really wacky wall and redoing the game center 
to 0 0
Stuff I want to go over again: pointers and 
memory allocation and some structs stuff. 