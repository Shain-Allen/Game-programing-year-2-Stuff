#pragma once

class Point
{
public:
    float x;
    float y;

    Point();
    Point(float x_, float y_);
};

